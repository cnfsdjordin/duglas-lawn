# Douglas Lawn And Landscaping 🌿

**Professional Landscaping Services — Houston, TX**

> 4.9 ★ rated · 115 Google Reviews · Latino-owned business

## 🚀 Deploy to GitHub Pages

1. Fork or upload this repo to your GitHub account
2. Go to **Settings → Pages**
3. Set Source to `main` branch, folder `/root`
4. Click **Save** — your site will be live at:
   `https://yourusername.github.io/douglas-lawn`

## 📁 Project Structure

```
douglas-lawn/
├── index.html      ← Homepage
├── css/style.css   ← Styles
├── js/main.js      ← JavaScript
└── images/         ← Add your photos here
```

## 📞 Contact

- **Phone:** (346) 251-2636
- **Address:** 14230 Wunderlich Rd, Houston, TX 77069
- **Hours:** Mon–Sat, Open until 6 PM

## ✏️ Customization

- Swap images in the `images/` folder
- Edit business info in `index.html`
- Change colors in `css/style.css` (look for `:root` CSS variables)

---
Built with HTML, CSS & JavaScript — no frameworks, no build step needed.
