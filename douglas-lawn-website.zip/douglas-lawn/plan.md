# Douglas Lawn And Landscaping — Website Plan

## Project Overview
A professional landscaping business website for Douglas Lawn And Landscaping, based in Houston, TX.
Designed for easy GitHub deployment via GitHub Pages (zero build step required).

---

## Tech Stack
- **HTML5** — Semantic, accessible markup
- **CSS3** — Custom properties, Flexbox, Grid, animations
- **Vanilla JavaScript** — Lightweight, no frameworks needed
- **Font Awesome CDN** — Icons
- **Google Fonts CDN** — Typography
- **GitHub Pages** — Free static hosting (no server required)

---

## File Structure
```
douglas-lawn/
├── index.html          ← Main homepage (entry point)
├── plan.md             ← This file
├── README.md           ← GitHub repo description & deployment instructions
├── css/
│   └── style.css       ← All styles
├── js/
│   └── main.js         ← Interactions (mobile menu, scroll effects, etc.)
└── images/
    └── (place your photos here — .jpg or .webp preferred)
        Suggested names:
        - hero-bg.jpg
        - patio1.jpg
        - lawn1.jpg
        - sprinkler.jpg
        - flower-bed.jpg
        - team.jpg
```

---

## Pages / Sections (Single Page)
1. **Header / Nav** — Logo + phone number + sticky navigation
2. **Hero** — Big tagline, CTA buttons (Call Now, Get a Quote)
3. **Services** — Lawn care, paver patios, sprinkler systems, flower beds, french drains
4. **About** — Latino-owned, Houston local, Douglas's story
5. **Reviews** — 4.9 ★ rating, 115 reviews, featured Google reviews
6. **Gallery** — Photo grid (replace placeholder images with your own)
7. **Contact** — Address, phone, hours, embedded Google Map
8. **Footer** — Copyright, social links

---

## Deployment Options

### Option A — GitHub Pages (Recommended, Free)
1. Create a GitHub account at github.com
2. Create a new repository named `douglas-lawn` (or any name)
3. Upload all files from this folder
4. Go to repo Settings → Pages → Source: `main` branch → `/root`
5. Your site goes live at: `https://yourusername.github.io/douglas-lawn`

### Option B — Custom Domain
1. Buy a domain (e.g., `douglaslawnhouston.com`) from Namecheap or GoDaddy (~$12/yr)
2. In GitHub Pages settings, add your custom domain
3. In your domain registrar, add a CNAME record pointing to `yourusername.github.io`
4. GitHub auto-generates free SSL (HTTPS)

### Option C — Netlify (Drag & Drop, also free)
1. Go to netlify.com and create a free account
2. Drag the entire `douglas-lawn` folder onto the Netlify dashboard
3. Live in 30 seconds with a free `.netlify.app` URL
4. Can also connect your custom domain

---

## Adding Your Own Photos
- Drop `.jpg` or `.webp` images into the `images/` folder
- Update `index.html` `<img src="images/yourphoto.jpg">` tags to match your filenames
- Recommended sizes: Hero = 1920×1080px, Gallery = 800×600px

---

## Business Info Included
- **Name:** Douglas Lawn And Landscaping
- **Rating:** 4.9 ★ (115 reviews)
- **Address:** 14230 Wunderlich Rd, Houston, TX 77069
- **Phone:** (346) 251-2636
- **Hours:** Open · Closes 6 PM
- **Identity:** Latino-owned business
