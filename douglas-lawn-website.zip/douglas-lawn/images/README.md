# Images Folder

Drop your photos here! Recommended filenames:

- `hero-bg.jpg` — Hero background image (1920×1080px)
- `team.jpg` — Photo of Douglas and/or his team (800×600px)
- `patio1.jpg` — Paver patio project photo
- `patio2.jpg` — Another patio photo
- `lawn1.jpg` — Lawn care photo
- `flower-bed.jpg` — Flower bed photo
- `sprinkler.jpg` — Sprinkler system photo
- `backyard.jpg` — Full yard transformation

After adding photos, update `index.html`:
1. In the **About** section: replace the placeholder `<div>` with `<img src="images/team.jpg" alt="Douglas and team">`
2. In the **Gallery** section: replace `<div class="gallery-ph">` with `<img src="images/patio1.jpg" alt="Paver patio">`

Use `.jpg` or `.webp` format for best performance.
